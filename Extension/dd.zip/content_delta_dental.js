// content_delta_dental.js - Multi-Layout Resilient Scraper for Delta Dental

const clean = (s) => (s || "").trim().replace(/\s+/g, ' ');

function scrapeDeltaDentalFull() {
    const text = document.body.innerText || "";
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

    console.log(`[Delta Dental Scraper] Scanning ${lines.length} lines of text...`);

    // Helper to find simple key-value lines, e.g. "Name: Zharisse Williams"
    function findKeyValue(regex) {
        for (let i = 0; i < lines.length; i++) {
            const m = lines[i].match(regex);
            if (m && m[1]) return clean(m[1]);
        }
        return "N/A";
    }

    // Helper to find financial values (Annual Max, Deductibles)
    // Works by finding the label line, then scanning the next 3 lines for "Total Available:" or a dollar amount.
    function findFinancialValue(labelRegex) {
        for (let i = 0; i < lines.length; i++) {
            if (labelRegex.test(lines[i])) {
                for (let j = i + 1; j < Math.min(lines.length, i + 4); j++) {
                    const line = lines[j];
                    if (line.includes("Total Available:")) {
                        const m = line.match(/Total Available:\s*\$\s*([\d,]+\.?\d*)/i);
                        if (m) return `$ ${parseFloat(m[1].replace(/,/g, '')).toFixed(2)}`;
                    }
                    const mDollarOnly = line.match(/^\s*\$\s*([\d,]+\.?\d*)\s*$/);
                    if (mDollarOnly) return `$ ${parseFloat(mDollarOnly[1].replace(/,/g, '')).toFixed(2)}`;
                    
                    // Out-of-network or other formats: "Used: $0.00 / Remaining: $1,500.00"
                    if (line.includes("Remaining:")) {
                        const mRem = line.match(/Remaining:\s*\$\s*([\d,]+\.?\d*)/i);
                        if (mRem) return `$ ${parseFloat(mRem[1].replace(/,/g, '')).toFixed(2)}`;
                    }
                }
            }
        }
        return null;
    }

    // Helper to search and parse the procedure limits table
    function findProcedureRow(nameRegex) {
        for (let i = 0; i < lines.length; i++) {
            if (nameRegex.test(lines[i])) {
                // If it's a tab-separated table row, split it
                const parts = lines[i].split('\t').map(p => p.trim());
                if (parts.length >= 2) {
                    return {
                        allowed: parts[1],
                        age: parts[2] || "N/A",
                        next: parts[3] || "N/A",
                        remaining: parts[4] || "N/A"
                    };
                }
                // If the columns are printed on subsequent lines
                const nextParts = [];
                for (let j = i + 1; j < Math.min(lines.length, i + 5); j++) {
                    nextParts.push(lines[j]);
                }
                return {
                    allowed: nextParts[0] || "N/A",
                    age: nextParts[1] || "N/A",
                    next: nextParts[2] || "N/A",
                    remaining: nextParts[3] || "N/A"
                };
            }
        }
        return null;
    }

    // Coinsurance Fallbacks / Extractor
    // Often coinsurance % shows as "Diagnostic(1351) 100%" or "Preventive 100%" or "Basic 80%" or "Crowns 50%"
    function findCoinsurance(labelRegex, defaultVal) {
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (labelRegex.test(line)) {
                const m = line.match(/(\d+%\s*(?:Premier|PPO|Out of Network)?|\d+%\s*)/i);
                if (m) {
                    const pctMatch = m[1].match(/(\d+%)/);
                    if (pctMatch) return pctMatch[1];
                }
                // Check adjacent lines
                for (let j = i + 1; j < Math.min(lines.length, i + 3); j++) {
                    const pctMatch = lines[j].match(/(\d+%)/);
                    if (pctMatch) return pctMatch[1];
                }
            }
        }
        return defaultVal;
    }

    // --- 1. PATIENT INFO ---
    const patientName = findKeyValue(/Name:\s*(.*)/i);
    const relationship = findKeyValue(/Relationship:\s*(.*)/i);

    // --- 2. PLAN DETAILS ---
    const groupName = findKeyValue(/Group Name:\s*(.*)/i);
    const groupNumber = findKeyValue(/Group Number:\s*(.*)/i);
    const benefitPlanName = findKeyValue(/Benefit Plan Name:\s*(.*)/i);
    const effectiveDate = findKeyValue(/Effective Date:\s*(.*)/i);

    // --- 3. FINANCIALS (Individual & Family Max/Ded) ---
    // Extract PPO first, fall back to Premier, then general
    const annualMax = findFinancialValue(/INDV Prevention First.*\(PPO\)/i) || 
                      findFinancialValue(/INDV Prevention First.*\(Premier\)/i) ||
                      findFinancialValue(/Annual Maximum|INDV Prevention First/i) || 
                      "$ 1500.00";

    const orthoMax = findFinancialValue(/Orthodontic Services LT.*\(PPO\)/i) || 
                     findFinancialValue(/Orthodontic Services LT.*\(Premier\)/i) ||
                     findFinancialValue(/Orthodontic Services LT/i) || 
                     "$ 1500.00";

    const individualDeductible = findFinancialValue(/Individual Annual Deductible.*\(Premier\)/i) || 
                                 findFinancialValue(/Individual Annual Deductible/i) || 
                                 "$ 25.00";

    const familyDeductible = findFinancialValue(/Family Annual Deductible.*\(Premier\)/i) || 
                             findFinancialValue(/Family Annual Deductible/i) || 
                             "$ 50.00";

    // --- 4. COINSURANCE RATES ---
    const diagPct = findCoinsurance(/Diagnostic|Periodic Exam/i, "100%");
    const prevPct = findCoinsurance(/Preventive|Cleaning/i, "100%");
    const basicPct = findCoinsurance(/Basic Restor|Filling/i, "80%");
    const majorPct = findCoinsurance(/Major Restor|Crown|Onlay/i, "50%");
    const orthoPct = findCoinsurance(/Orthodontic|Ortho/i, "50%");

    // --- 5. FREQUENCIES AND LIMITS (Procedure details) ---
    const bwxRow = findProcedureRow(/Bitewing X-Rays/i);
    const cleaningRow = findProcedureRow(/Cleanings/i);
    const examRow = findProcedureRow(/Exams/i);
    const fluorideRow = findProcedureRow(/Fluoride/i);
    const fillingRow = findProcedureRow(/Fillings/i);

    // Construct the structured JSON payload matching the target formats
    const data = {
        source: "Delta Dental Portal",
        timestamp: new Date().toISOString(),
        summary: {
            group_name: groupName !== "N/A" ? groupName : (benefitPlanName !== "N/A" ? benefitPlanName : "Delta Dental Plan"),
            group_number: groupNumber
        },
        financials: {
            individual_deductible: { total: individualDeductible },
            family_deductible: { total: familyDeductible },
            annual_max: { total: annualMax },
            ortho_lifetime: { total: orthoMax }
        },
        patient: {
            name: patientName,
            relationship: relationship
        },
        benefit_coverage: {
            procedures: [
                {
                    procedure_code: "D0120", // Exams
                    benefit_level: diagPct,
                    age_limit: "0-99",
                    late_date_of_service: examRow?.next || "—"
                },
                {
                    procedure_code: "D1206", // Fluoride
                    benefit_level: prevPct,
                    age_limit: fluorideRow?.age?.includes("0-18") ? "0-18" : (fluorideRow?.age || "0-18"),
                    late_date_of_service: fluorideRow?.next || "—"
                },
                {
                    procedure_code: "D1110", // Cleanings
                    benefit_level: prevPct,
                    age_limit: "0-99",
                    late_date_of_service: cleaningRow?.next || "—"
                },
                {
                    procedure_code: "D0274", // Bitewings
                    benefit_level: diagPct,
                    age_limit: "0-99",
                    late_date_of_service: bwxRow?.next || "—"
                },
                {
                    procedure_code: "D2331", // Fillings
                    benefit_level: basicPct,
                    age_limit: "0-99",
                    late_date_of_service: fillingRow?.next || "—"
                },
                {
                    procedure_code: "D2740", // Major Crowns
                    benefit_level: majorPct,
                    age_limit: "0-99"
                },
                {
                    procedure_code: "D8080", // Orthodontics
                    benefit_level: orthoPct,
                    age_limit: "0-26"
                }
            ]
        }
    };

    return data;
}

function runDeltaDentalCrawl() {
    if (!chrome.runtime?.id) return;

    console.log("[Delta Dental Scraper] Crawling page content...");
    const data = scrapeDeltaDentalFull();

    chrome.storage.local.get("audit_context", (result) => {
        let context = result.audit_context || {};
        context.delta_dental_data = data;
        chrome.storage.local.set({ "audit_context": context }, () => {
            console.log("[Delta Dental Scraper] Scraped data saved to context:", data);
        });
    });
}

// Auto-run scraping shortly after page load
setTimeout(runDeltaDentalCrawl, 3000);

// Message Listener for manual crawls from the popup script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.command === "START_CRAWL") {
        runDeltaDentalCrawl();
        sendResponse({ status: "Delta Dental Crawl Completed" });
    }
});
